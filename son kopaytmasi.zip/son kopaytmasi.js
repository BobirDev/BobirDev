const arr = [5,6,7];
    const son = arr.reduce((son1,son2) => {
        return son1 * son2
    },1);
    alert(son);