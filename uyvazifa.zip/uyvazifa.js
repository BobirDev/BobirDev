const arr = ['10', '20', '30', '40', '50', '60', '70'];
{
for (let i = 0; i < arr.length; i++)
    console.log(i*100);
  } 